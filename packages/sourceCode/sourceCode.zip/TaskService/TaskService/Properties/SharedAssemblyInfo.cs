﻿using System.Reflection;

[assembly: AssemblyDescription("https://taskscheduler.codeplex.com/")]
[assembly: AssemblyCompany("CodePlex Community")]
[assembly: AssemblyProduct("TaskService")]
[assembly: AssemblyCopyright("Copyright © 2017")]
[assembly: AssemblyVersion("2.5.28.0")]
[assembly: AssemblyFileVersion("2.5.28.0")]
