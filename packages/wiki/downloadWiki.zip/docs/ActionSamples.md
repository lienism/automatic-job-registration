# Action Samples
All actions are derived from the abstract {{Action}} class. All versions of the base library support the {{ExecAction}}. It only has three properties that allow it to run an executable with parameters.

{code:c#}
ExecAction ea1 = new ExecAction("notepad.exe", "file.txt", null);
ExecAction ea2 = new ExecAction();
ea2.Path = "notepad.exe";
ea.Arguments = "file2.txt";
{code:c#}
## Cross-platform Support
Post Vista, in the V2 library, there are three new actions. Under V1 systems (XP/WS2003 and earlier), these actions can be enabled via PowerShell and setting the {{TaskDefinition.Actions.PowerShellConversion}} property to {{PowerShellActionPlatformOption.All}}. Turning on support for PowerShell under V1 systems also allow the library to support more than one action.

{code:c#}
TaskDefinition td = TaskService.Instance.NewTask()
td.Actions.PowerShellConversion = PowerShellActionPlatformOption.All;
// Define rest of task and register...
{code:c#}

This same property can be used to prevent PowerShell from being used to convert {{EmailAction}} and {{ShowMessageAction}} actions under Windows 8 and newer systems:

{code:c#}
TaskDefinition td = TaskService.Instance.NewTask()
td.Actions.PowerShellConversion = PowerShellActionPlatformOption.Never;
// Define rest of task and register...
{code:c#}

## Email, Message and COM Object Actions
The {{EmailAction}} allows for an email to be sent when the task is triggered. It works as follows:

{code:c#}
EmailAction eAction = new EmailAction("Task fired", "sender@email.com", "recipient@email.com", "You just got a message", "smtp.company.com");
eAction.Cc = "alternate@email.com";
{code:c#}

You can also display a message when the trigger fires using the {{ShowMessageAction}}.

{code:c#}
ShowMessageAction msg = new ShowMessageAction("You just got a message!", "SURPRISE");
{code:c#}

The last action is the most complex. It allows the task to execute and In-Proc COM server object that implements the {{ITaskHandler}} interface. There is a sample project that shows how to do this in the Downloads section, but here is how to define the action.

{code:c#}
ComHandlerAction comAction = new ComHandlerAction(new Guid("{CE7D4428-8A77-4c5d-8A13-5CAB5D1EC734}"));
comAction.Data = "Something specific the COM object needs to execute. This can be left unassigned as well.";
{code:c#}