# Trigger Samples
First thing to note is that all triggers derive from the abstract {{Trigger}} class. There are some basic properties in this class which can be set for all triggers. For the sample below, we'll use the {{TimeTrigger}} derived class but only set properties available on the {{Trigger}} class.

All triggers have constructors that provide a shortcut to setting common properties.
### General Trigger Creation
{code:c#}
TimeTrigger tt = new TimeTrigger();
// **** V1 and V2 properties ******************************************
// Disable the trigger from firing the task
tt.Enabled = false; // Default is true
// Set the start time for today at 11:00 p.m.
tt.StartBoundary = DateTime.Today + TimeSpan.FromHours(23); // Default is the time the trigger is instantiated
// Set the last time the trigger will run to a year from now.
tt.EndBoundary = DateTime.Today + TimeSpan.FromDays(365); // Default is DateTime.MaxValue (or forever)
// Set the time in between each repetition of the task after it starts to 30 minutes.
tt.Repetition.Interval = TimeSpan.FromMinutes(30); // Default is TimeSpan.Zero (or never)
// Set the time the task will repeat to 1 day.
tt.Repetition.Duration = TimeSpan.FromDays(1); // Default is TimeSpan.Zero (or never)
// Set the task to end even if running when the duration is over
tt.Repetition.StopAtDurationEnd = true; // Default is false;

// **** V2 only properties ********************************************
// Set an identifier to be used when logging
tt.Id = "Some unique identifier";
// Set the maximum time this task can run once triggered to one hour.
tt.ExecutionTimeLimit = TimeSpan.FromHours(1); // Default is TimeSpan.Zero (or never)

// Trigger must then be added to the task's trigger collection
myTask.Definition.Triggers.Add(tt);
{code:c#}
### Updating a trigger
{code:c#}
// Get an instance of an existing task
Task myTask = myTaskSvc.GetTask("MyTaskName");

// Check to ensure you have a trigger and it is the one want
if (myTask.Definition.Triggers.Count > 0 && myTask.Definition.Triggers[0](0) is TimeTrigger)
{
   // Remove current task
   myTask.Definition.Triggers.RemoveAt(0);
   // Add new trigger that will run at noon today
   myTask.Definition.Triggers.Add(new TimeTrigger(DateTime.Today + TimeSpan.FromHours(12)));
}

// Register the changes (Note: if there is a password associated with the task, 
// you will need to register using the TaskFolder.RegisterTaskDefinition method.
myTask.RegisterChanges();
{code:c#}
## Triggers that work on all Windows OS variants (V1 & V2)
### BootTrigger
A {{BootTrigger}} will fire when the system starts. It can only be delayed. All triggers that support a delay implement the {{ITriggerDelay}} interface.

{code:c#}
// Create trigger that fires 5 minutes after the system starts.
BootTrigger bt = new BootTrigger();
bt.Delay = TimeSpan.FromMinutes(5);  // V2 only
{code:c#}
### DailyTrigger
A {{DailyTrigger}} will fire at a specified time every day or interval of days.

{code:c#}
// Create a trigger that runs every other day and will start randomly between 10 a.m. and 12 p.m.
DailyTrigger dt = new DailyTrigger();
dt.StartBoundary = DateTime.Today + TimeSpan.FromHours(10);
dt.DaysInterval = 2;
dt.RandomDelay = TimeSpan.FromHours(2); // V2 only
{code:c#}
### IdleTrigger
An {{IdleTrigger}} will fire when the system becomes idle. It is generally a good practice to set a limit on how long it can run using the ExecutionTimeLimit property.

{code:c#}
IdleTrigger it = new IdleTrigger();
{code:c#}
### LogonTrigger
A {{LogonTrigger}} will fire after a user logs on. It can only be delayed. Under V2, you can specify which user it applies to.

{code:c#}
// Create a trigger that fires 15 minutes after the user Mickey logs in
LogonTrigger lt = new LogonTrigger();
lt.Delay = TimeSpan.FromMinutes(15); // V2 only
lt.UserId = "Mickey"; // V2 only
{code:c#}
### MonthlyTrigger
A {{MonthlyTrigger}} will fire at a specific time on specified days of the month.

{code:c#}
// Create a trigger that will run at 10 a.m. on the 10th, 20th and last days of July and November
MonthlyTrigger mTrigger = new MonthlyTrigger();
mTrigger.StartBoundary = DateTime.Today + TimeSpan.FromHours(10);
mTrigger.DaysOfMonth = new int[]() { 10, 20 };
mTrigger.MonthsOfYear = MonthsOfTheYear.July | MonthsOfTheYear.November;
mTrigger.RunOnLastDayOfMonth = true; // V2 only
{code:c#}
### MonthlyDOWTrigger
A {{MonthlyDOWTrigger}} runs at a specific time on specified days of specified weeks on specified months.

{code:c#}
// Create a trigger that runs Saturday in the first and last week of January and Decemeber at 1 a.m.
MonthlyDOWTrigger mdTrigger = new MonthlyDOWTrigger();
mdTrigger.StartBoundary = DateTime.Today + TimeSpan.FromHours(1);
mdTrigger.DaysOfWeek = DaysOfTheWeek.Saturday;
mdTrigger.MonthsOfYear = MonthsOfTheYear.January | MonthsOfTheYear.December;
mdTrigger.WeeksOfMonth = WhichWeek.FirstWeek | WhichWeek.LastWeek;
{code:c#}
### TimeTrigger
A {{TimeTrigger}} runs at a specified date and time.

{code:c#}
// Create a trigger that runs the last minute of this year
TimeTrigger tTrigger = new TimeTrigger();
tTrigger.StartBoundary = new DateTime(DateTime.Today.Year, 12, 31, 23, 59, 0);
{code:c#}
### WeeklyTrigger
A {{WeeklyTrigger}} runs at a specified time on specified days of the week every week or interval of weeks.

{code:c#}
// Create a trigger that runs on Monday every third week just after midnight.
WeeklyTrigger wTrigger = new WeeklyTrigger();
wTrigger.StartBoundary = DateTime.Today + TimeSpan.FromSeconds(15);
wTrigger.DaysOfWeek = DaysOfTheWeek.Monday;
wTrigger.WeeksInterval = 3;
{code:c#}
## Triggers that run on Windows Vista and later
### EventTrigger
The {{EventTrigger}} runs when a system event fires.

{code:c#}
// Create a triger that will fire whenever a level 2 system event fires.
EventTrigger eTrigger = new EventTrigger();
eTrigger.Subscription = @"<QueryList><Query Id='1'><Select Path='System'>*[System/Level=2](System_Level=2)</Select></Query></QueryList>";
eTrigger.ValueQueries.Add("Name", "Value");
{code:c#}
### RegistrationTrigger
The {{RegistrationTrigger}} will fire after the task is registered (saved). It is good to put in a delay.

{code:c#}
// Create a trigger that will fire the task 5 minutes after its registered
RegistrationTrigger rTrigger = new RegistrationTrigger();
rTrigger.Delay = TimeSpan.FromMinutes(5);
{code:c#}
### SessionStateChangeTrigger
The {{SessionStateChangeTrigger}} will fire after six different system events: connecting or disconnecting locally or remotely, or locking or unlocking the session.

{code:c#}
new SessionStateChangeTrigger { StateChange = TaskSessionStateChangeType.ConsoleConnect, UserId = "joe" };
new SessionStateChangeTrigger { StateChange = TaskSessionStateChangeType.ConsoleDisconnect };
new SessionStateChangeTrigger { StateChange = TaskSessionStateChangeType.RemoteConnect };
new SessionStateChangeTrigger { StateChange = TaskSessionStateChangeType.RemoteDisconnect };
new SessionStateChangeTrigger { StateChange = TaskSessionStateChangeType.SessionLock, UserId = "joe" };
new SessionStateChangeTrigger { StateChange = TaskSessionStateChangeType.SessionUnlock };
{code:c#}