## Documentation Home Page
There is a help file included with the download that provides an overview of the various classes. The [Microsoft MSDN documentation](http://msdn.microsoft.com/en-us/library/windows/desktop/aa446802(v=VS.85).aspx) provides an excellent overview of the Task Scheduler along with details around security and permission, idle conditions, and trigger repetition.

* The [Classes Overview](Classes-Overview) describes each of the major classes and how they are used.
* The [Examples Page](Examples) shows some C# code that demonstrates almost every function of the library.
	* [Trigger Example Code](TriggerSamples) has specific examples around triggers.
	* [Action Example Code](ActionSamples) has specific examples around actions.
	* [Task Event Management Code](EventSamples) has examples around how to view and watch events related to tasks.
	* [Security Explanations and Samples](TaskSecurity) show how to connect to remote servers and how to create tasks that run in different security contexts (system account, user account, elevated, etc.)
	* [PowerShell Examples](PowerShell) has examples on how to use the library from PowerShell.
* The [Installation & Samples Page](Install) explains how to use this library in your own projects and includes a sample project.
Below is a brief example of how to use the library from C#.

{code:c#}
using System;
using Microsoft.Win32.TaskScheduler;

class Program
{
   static void Main(string[]() args)
   {
      // Create a new task definition for the local machine and assign properties
      TaskDefinition td = TaskService.Instance.NewTask();
      td.RegistrationInfo.Description = "Does something";

      // Add a trigger that, starting tomorrow, will fire every other week on Monday
      // and Saturday and repeat every 10 minutes for the following 11 hours
      WeeklyTrigger wt = new WeeklyTrigger();
      wt.StartBoundary = DateTime.Today.AddDays(1);
      wt.DaysOfWeek = DaysOfTheWeek.Monday | DaysOfTheWeek.Saturday;
      wt.WeeksInterval = 2;
      wt.Repetition.Duration = TimeSpan.FromHours(11);
      wt.Repetition.Interval = TimeSpan.FromMinutes(10);
      td.Triggers.Add(wt);

      // Create an action that will launch Notepad whenever the trigger fires
      td.Actions.Add("notepad.exe", "c:\\test.log");

      // Register the task in the root folder of the local machine
      TaskService.Instance.RootFolder.RegisterTaskDefinition("Test", td);
   }
}
{code:c#}

Here's the same as above but in VB.NET

{code:vb.net}
Imports Microsoft.Win32.TaskScheduler

Module Module1

    Sub Main()
        Using ts As New TaskService()
            ' Create a new task definition and assign properties
            Dim td As TaskDefinition = ts.NewTask
            td.RegistrationInfo.Description = "Does something"

            ' Add a trigger that will, starting tomorrow, fire every other week on Monday
            ' and Saturday and repeat every 10 minutes for the following 11 hours
            Dim wt As New WeeklyTrigger()
            wt.StartBoundary = DateTime.Today.AddDays(1)
            wt.DaysOfWeek = DaysOfTheWeek.Monday Or DaysOfTheWeek.Saturday
            wt.WeeksInterval = 2
            wt.Repetition.Duration = TimeSpan.FromHours(11)
            wt.Repetition.Interval = TimeSpan.FromMinutes(10)
            td.Triggers.Add(wt)

            ' Add an action (shorthand) that runs Notepad
            td.Actions.Add(New ExecAction("notepad.exe", "c:\test.log"))

            ' Register the task in the root folder
            ts.RootFolder.RegisterTaskDefinition("Test", td)
        End Using
    End Sub

End Module
{code:vb.net}

If you're really into shorthand code, here's almost the same functionality as the C# code above, but much shorter:

{code:c#}
using System;
using Microsoft.Win32.TaskScheduler;

class Program
{
   static void Main(string[]() args)
   {
      TaskService.Instance.AddTask("Test", new DailyTrigger { DaysInterval = 2 },
         new ExecAction("notepad.exe", "c:\\test.log", null));
   }
}
{code:c#}

Alternately, you can use the library declaratively or "fluently":

{code:c#}
Task t = TaskService.Instance.Execute("notepad.exe").WithArguments(@"c:\test.log").Every(2).Days().AsTask("Test");
{code:c#}