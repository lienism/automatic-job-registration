**Manual Installation**
# From the Downloads page, download the TaskScheduler.zip and TaskSchedulerEditor.zip files and extract all their contents to a folder on your system. 
# From your project within Visual Studio add references to all the assemblies in that folder
## Microsoft.Win32.TaskScheduler.dll (_required_)
## Microsoft.Win32.TaskSchedulerEditor.dll (_only if UI elements are required: TaskEditDialog, etc._)
## TimeSpan2.dll (_required if Microsoft.Win32.TaskSchedulerEditor.dll is used_)
## CubicOrange.Windows.Forms.ActiveDirectory.dll (_required if Microsoft.Win32.TaskSchedulerEditor.dll is used and tasks can be edited_)
## AeroWizard.dll (_only if TaskSchedulerWizard control is used_)
## GroupControls.dll (_only if TaskSchedulerWizard control is used_)
# You should then be able to use any of the classes either using the 'using' directive and referencing 'Microsoft.Win32.TaskScheduler' or by using the full name of the class. 

**NuGet Installation**
# Install NuGet from http://nuget.org/. 
# Using NuGet from within Visual Studio, add references to the TaskScheduler and TaskSchedulerEditor packages 
# Enjoy the benefit of having NuGet automatically keep all your assemblies up to date! 

**Sample project**
This project is a simple form that has a button that shows a task. It is using a current build of the library which may not be the most recent. +Do not use the TaskScheduler assemblies in this download+ for your project. Please use the ones from the [downloads page](http://taskscheduler.codeplex.com/releases).
* [SimpleTaskForm.zip](Install_SimpleTaskForm.zip)