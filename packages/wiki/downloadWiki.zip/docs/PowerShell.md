## PowerShell Examples
As a .NET library, all of the Task Scheduler Managed Wrapper can be used from within PowerShell. You simply need to load the assembly and then use the interop methods, like New-Object, to interact with the classes.
### Create a task
{code:powershell}
[Reflection.Assembly](Reflection.Assembly)::LoadFile("C:\CodeShare\Microsoft.Win32.TaskScheduler.dll")
[Microsoft.Win32.TaskScheduler.TaskService](Microsoft.Win32.TaskScheduler.TaskService)::Instance.AddTask("Test",
    [Microsoft.Win32.TaskScheduler.QuickTriggerType](Microsoft.Win32.TaskScheduler.QuickTriggerType)::Hourly, "cmd", "/param1")
{code:powershell}